package com.example.test;

import java.util.ArrayList;
import java.util.List;

public class reservationactivity {
    void show()
    {
        final List<String> ListItems = new ArrayList<>();
        ListItems.add("00:00~01:00");
        ListItems.add("01:00~02:00");
        ListItems.add("02:00~03:00");
        ListItems.add("03:00~04:00");
        ListItems.add("04:00~05:00");
        ListItems.add("05:00~06:00");
        ListItems.add("06:00~07:00");
        ListItems.add("07:00~08:00");
        ListItems.add("08:00~09:00");
        ListItems.add("09:00~10:00");
        ListItems.add("10:00~11:00");
        ListItems.add("11:00~12:00");
        ListItems.add("12:00~13:00");



    }

}
